# Semester III Web Technologies Assignments

### This is a repository for my University assignment
It deals with simple schools assignment for web technologies
All assignment contrubutes to my course work
